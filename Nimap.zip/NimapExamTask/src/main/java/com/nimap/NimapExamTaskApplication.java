package com.nimap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NimapExamTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(NimapExamTaskApplication.class, args);
	}

}
