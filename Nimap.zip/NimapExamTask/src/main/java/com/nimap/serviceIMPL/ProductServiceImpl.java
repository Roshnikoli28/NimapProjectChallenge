package com.nimap.serviceIMPL;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nimap.model.Category;
import com.nimap.model.Product;
import com.nimap.repositery.CategoryRepository;
import com.nimap.repositery.ProductRepo;
import com.nimap.repositery.ProductRepository;
import com.nimap.service.CategoryService;
import com.nimap.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductRepository productRepository;

	@Override
	public Product createProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	@Override
	public Product getProductById(Long id) {
		// TODO Auto-generated method stub
		return productRepository.findById(id).orElse(null);
	}

	@Override
	public Product updateProduct(Long id, Product productDetails) {
		Product product = productRepository.findById(id).orElse(null);
		if (product !=null) {
			product.setName(productDetails.getName()); 
			return productRepository.save(product);
		}
		return null;
				  
	}

	@Override
	public void deleteProduct(Long id) {
		productRepository.deleteById(id);

	}

	
	
}
