package com.nimap.service;

import java.util.List;

import com.nimap.model.Category;
import com.nimap.model.Product;

public interface ProductService {

	 Product createProduct(Product product);

	 Product getProductById(Long id);

	 Product updateProduct(Long id, Product productDetails);

	void deleteProduct(Long id);
}
